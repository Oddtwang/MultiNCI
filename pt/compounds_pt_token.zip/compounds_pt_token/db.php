<?php

function get_db_connection() {
    //TODO Replace host by db.inf.ufrgs.br
    $conecta = mysql_connect("db.inf.ufrgs.br", "mwe", "6TAuQDR8xulso") or print (mysql_error()); 
    mysql_select_db("mwe", $conecta) or print(mysql_error());
    return $conecta;
}
?>

